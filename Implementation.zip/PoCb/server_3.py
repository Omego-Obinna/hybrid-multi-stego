from flask import Flask, request, jsonify
import hmac
import hashlib
import os

app = Flask(__name__)

# Shared secret for MAC verification (this should match V_pri used by Amara)
V_pri = bytes.fromhex('b76852100c93c73966cb1b909abff1a08124b3f4f9357495fefdabe13998fac6')  # Example; replace with actual shared secret used for MAC

# Route to receive stego-image and MAC
@app.route('/receive_stego', methods=['POST'])
def receive_stego():
    if 'file' not in request.files or 'mac' not in request.form:
        response = {'status': 'error', 'message': 'Stego image or MAC missing'}
        print(f"Server Response: {response}")
        return jsonify(response), 400

    # Get the stego-image file and the MAC
    stego_file = request.files['file']
    received_mac = request.form['mac']

    # Save the received stego-image
    stego_image_path = "received_stego_image.png"
    stego_file.save(stego_image_path)

    # Read the stego-image for MAC verification
    with open(stego_image_path, "rb") as image_file:
        stego_image_data = image_file.read()

    # Print first 64 bytes of the received image for debugging
    print(f"First 64 bytes of received stego image (Ebere): {stego_image_data[:64]}")

    # Generate the MAC again using the received stego-image and shared secret V_pri
    generated_mac = hmac.new(V_pri, stego_image_data, hashlib.sha256).hexdigest()
    print(f"Generated MAC (Ebere): {generated_mac}")

    # Compare the received MAC with the generated MAC
    if hmac.compare_digest(received_mac, generated_mac):
        response = {'status': 'success', 'message': 'MAC verified successfully'}
    else:
        response = {'status': 'error', 'message': 'MAC verification failed'}

    # Print the server response and return it
    print(f"Server Response: {response}")
    return jsonify(response)

if __name__ == "__main__":
    # Enable debug mode to ensure print statements work properly
    app.run(host="0.0.0.0", port=5003, debug=True)

