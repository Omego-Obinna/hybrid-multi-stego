from flask import Flask, jsonify, request

app = Flask(__name__)

# File to store the received message (m_2)
M2_FILE = "m2.txt"

@app.route('/send_m2', methods=['POST'])
def receive_m2():
    data = request.json
    m_2 = data.get("m_2", "")

    # Store message in a text file
    with open(M2_FILE, "w") as f:
        f.write(m_2)

    return jsonify({"status": "m_2 received"}), 200

@app.route('/get_m_2', methods=['GET'])
def get_m2():
    # Read message from the file
    with open(M2_FILE, "r") as f:
        m_2 = f.read()
    
    return jsonify({"m_2": m_2}), 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5002)

