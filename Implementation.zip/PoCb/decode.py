import hmac
import hashlib
import os
from PIL import Image
import numpy as np

# Define V_pri directly in the script
V_pri = bytes.fromhex('b76852100c93c73966cb1b909abff1a08124b3f4f9357495fefdabe13998fac6')

# Function to read the masked message from a text file
def read_message(filename):
    """Reads the masked message from a file."""
    with open(filename, "r") as f:
        return f.read()

# Function to generate HMAC-based password P'
def generate_password(V_pri, cover_message):
    """Generates password P' using HMAC with V_pri and cover message."""
    P = hmac.new(V_pri, cover_message.encode(), hashlib.sha256).digest()
    return P

# Function to generate the stego key
def generate_stego_key(V_pri, P):
    """Generates stego-key k_stego' by hashing V_pri XOR P."""
    k_stego_input = bytes(a ^ b for a, b in zip(V_pri, P))
    k_stego = hashlib.sha256(k_stego_input).digest()
    return k_stego

# Function to extract message from an image using LSB
def extract_lsb(image_path, k_stego, message_length):
    """Extracts a binary message from an image using LSB based on k_stego."""
    img = Image.open(image_path)

    # Convert to grayscale or RGB as needed
    img = img.convert('L') if img.mode == 'L' else img.convert('RGB')
    pixels = np.array(img).flatten()

    # Set up random seed based on k_stego
    seed_value = int(hashlib.sha256(k_stego).hexdigest(), 16) % (2**32)
    np.random.seed(seed_value)
    indices = np.arange(len(pixels))
    np.random.shuffle(indices)

    # Extract message bits from the image
    extracted_bits = [str(pixels[i] & 1) for i in indices[:message_length]]
    return ''.join(extracted_bits)

# Function to unmask the secret message
def unmask_secret(b, m_1, k_stego):
    """Unmasks the secret message from masked message b using m_1 and k_stego."""
    m_1_bin = ''.join(format(ord(c), '08b') for c in m_1)
    k_stego_bin = ''.join(format(b, '08b') for b in k_stego)

    max_len = len(b)
    m_1_bin = m_1_bin.ljust(max_len, '0')
    k_stego_bin = k_stego_bin.ljust(max_len, '0')

    unmasked_message = ''.join(
        str(int(b[i]) ^ int(m_1_bin[i]) ^ int(k_stego_bin[i])) for i in range(max_len)
    )

    # Convert binary string back to text
    decoded_chars = [unmasked_message[i:i+8] for i in range(0, len(unmasked_message), 8)]
    decoded_message = ''.join(chr(int(char, 2)) for char in decoded_chars)
    return decoded_message

# Main function
if __name__ == "__main__":
    print(f"Loaded V_pri: {V_pri.hex()}")  # Tracing V_pri

    # Paths for the files needed
    stego_image_path = "received_stego_image.png"
    cover_message_file = "m1.txt"

    # Read the cover message
    if not os.path.exists(cover_message_file):
        print("Cover message file not found.")
        exit(1)
    m_1 = read_message(cover_message_file)
    print(f"Cover Message m_1: {m_1}")

    # Generate P' and k_stego'
    P_prime = generate_password(V_pri, m_1)
    print(f"Generated P' (Password): {P_prime.hex()}")  # Tracing P'
    k_stego_prime = generate_stego_key(V_pri, P_prime)
    print(f"Derived k_stego': {k_stego_prime.hex()}")  # Tracing k_stego'

    # Extract the masked message from the stego image
    message_length = 256  # Adjust based on message length; needs to match masking length
    masked_message_binary = extract_lsb(stego_image_path, k_stego_prime, message_length)
    print(f"Extracted Masked Message (Binary): {masked_message_binary[:64]}...")

    # Unmask the secret message
    secret_message = unmask_secret(masked_message_binary, m_1, k_stego_prime)
    print(f"Decoded Secret Message: {secret_message}")
