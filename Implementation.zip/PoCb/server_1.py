from flask import Flask, jsonify, request

app = Flask(__name__)

# File to store the received message (m_1)
M1_FILE = "m1.txt"

@app.route('/send_m1', methods=['POST'])
def receive_m1():
    data = request.json
    m_1 = data.get("m_1", "")

    # Store message in a text file
    with open(M1_FILE, "w") as f:
        f.write(m_1)

    return jsonify({"status": "m_1 received"}), 200

@app.route('/get_m_1', methods=['GET'])
def get_m1():
    # Read message from the file
    with open(M1_FILE, "r") as f:
        m_1 = f.read()
    
    return jsonify({"m_1": m_1}), 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001)

