import math
import textstat
import nltk
from collections import Counter
import matplotlib.pyplot as plt

# Ensure necessary NLTK corpora are downloaded
nltk.download('punkt')
nltk.download('words')

# Sample Cover Messages
cover_messages = [
    "laughs as they run through the tall grass.",
    "hops quietly through the garden, nibbling on fresh clover.",
    "scattering them across the ground.",
    "soft glow on the peaceful village below.",
    "flows steadily, reflecting the golden light of dusk.",
    "scent of pine trees through the forest",
    "against the shore, creating a soothing rhythm.",
    "they run through the tall grass."
]

# Entropy Calculation for Cover Messages
def calculate_entropy(text):
    """Calculate the entropy of the given text based on character distribution."""
    probability_distribution = Counter(text)
    total_chars = sum(probability_distribution.values())
    
    # Normalize probabilities
    probabilities = [freq / total_chars for freq in probability_distribution.values()]
    
    # Calculate entropy using Shannon entropy formula
    entropy_value = -sum(p * math.log2(p) for p in probabilities)
    return entropy_value

# Linguistic Plausibility Check using textstat
def check_linguistic_plausibility(text):
    """Check linguistic plausibility using readability scores and grammar checks."""
    readability_index = textstat.flesch_reading_ease(text)
    grammatical_check = textstat.text_standard(text, float_output=True)
    return readability_index, grammatical_check

# Function to customize font size and boldness
def set_font_options(ax, title_size=14, label_size=12, tick_size=10, bold=False):
    """Set font size and boldness for a given plot."""
    weight = 'bold' if bold else 'normal'
    ax.set_title(ax.get_title(), fontsize=title_size, weight=weight)
    ax.set_xlabel(ax.get_xlabel(), fontsize=label_size, weight=weight)
    ax.set_ylabel(ax.get_ylabel(), fontsize=label_size, weight=weight)
    ax.tick_params(axis='both', which='major', labelsize=tick_size)

# Perform Analysis and Plot Results
def analyze_and_plot(cover_messages, title_size=14, label_size=12, tick_size=10, bold=False):
    entropies = []
    readability_scores = []
    grammar_levels = []
    message_ids = list(range(1, len(cover_messages) + 1))
    
    print("Cover Message Analysis Report:\n")

    # Entropy Analysis
    for i, message in enumerate(cover_messages):
        entropy_value = calculate_entropy(message)
        entropies.append(entropy_value)
        print(f"Message {i+1}: '{message}' -> Entropy: {entropy_value:.4f}")
        
    print("\nLinguistic Plausibility Check:")
    
    # Linguistic Plausibility Check
    for i, message in enumerate(cover_messages):
        readability, grammar_level = check_linguistic_plausibility(message)
        readability_scores.append(readability)
        grammar_levels.append(grammar_level)
        print(f"Message {i+1}: '{message}' -> Readability: {readability:.2f}, Grammar Level: {grammar_level}")

    # Plot Entropy Calculation
    fig, ax1 = plt.subplots(figsize=(10, 8))
    ax1.bar(message_ids, entropies, color='blue', alpha=0.7)
    ax1.set_title('Entropy Calculation for Cover Messages', fontsize=title_size, weight='bold' if bold else 'normal')
    ax1.set_xlabel('Message ID', fontsize=label_size, weight='bold' if bold else 'normal')
    ax1.set_ylabel('Entropy Value', fontsize=label_size, weight='bold' if bold else 'normal')
    ax1.tick_params(axis='both', which='major', labelsize=tick_size)
    plt.grid(True)
    plt.show()

    # Plot Linguistic Plausibility (Readability and Grammar Level)
    fig, ax2 = plt.subplots(figsize=(10, 8))
    ax2.bar(message_ids, readability_scores, color='green', alpha=0.7, label='Readability Index')
    ax2.set_xlabel('Message ID', fontsize=label_size, weight='bold' if bold else 'normal')
    ax2.set_ylabel('Readability Index', color='green', fontsize=label_size, weight='bold' if bold else 'normal')
    ax2.tick_params(axis='y', labelcolor='green', labelsize=tick_size)
    ax2.tick_params(axis='both', which='major', labelsize=tick_size)
    
    ax3 = ax2.twinx()
    ax3.plot(message_ids, grammar_levels, color='red', marker='o', label='Grammar Level')
    ax3.set_ylabel('Grammar Level', color='red', fontsize=label_size, weight='bold' if bold else 'normal')
    ax3.tick_params(axis='y', labelcolor='red', labelsize=tick_size)
    
    plt.title('Linguistic Plausibility for Cover Messages', fontsize=title_size, weight='bold' if bold else 'normal')
    fig.tight_layout()
    plt.grid(True)
    plt.show()

# Example Execution
if __name__ == "__main__":
    # Perform cover message analysis with font options
    analyze_and_plot(cover_messages, title_size=16, label_size=14, tick_size=12, bold=True)

