import requests

# URLs for the two servers
server_1_url = "http://192.168.56.103:5001/send_m1"  # Ebere's IP for receiving m_1 on port 5001
server_2_url = "http://192.168.56.103:5002/send_m2"  # Ebere's IP for receiving m_2 on port 5002

# Load m_1 and m_2 from files
def load_message(filename):
    with open(filename, "r") as f:
        return f.read()

def send_m1():
    """Send m_1 to server 1."""
    m_1 = load_message("m1.txt")
    response = requests.post(server_1_url, json={"m_1": m_1})
    print(f"Server 1 Response: {response.json()}")

def send_m2():
    """Send m_2 to server 2."""
    m_2 = load_message("m2.txt")
    response = requests.post(server_2_url, json={"m_2": m_2})
    print(f"Server 2 Response: {response.json()}")

if __name__ == "__main__":
    # Send cover messages m_1 and m_2 to respective servers
    send_m1()
    send_m2()
