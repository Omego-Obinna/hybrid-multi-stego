import hmac
import hashlib
import os

# Directly define V_pri within the script for consistency
V_pri = bytes.fromhex('b76852100c93c73966cb1b909abff1a08124b3f4f9357495fefdabe13998fac6')

# Function to generate HMAC-based single-use password P
def generate_password(V_pri, cover_message):
    """Generates a password P using HMAC and the cover message."""
    P = hmac.new(V_pri, cover_message.encode(), hashlib.sha256).digest()
    return P

# Function to generate the stego-key
def generate_stego_key(V_pri, P):
    """Generates stego-key k_stego by hashing V_pri XOR P."""
    k_stego_input = bytes(a ^ b for a, b in zip(V_pri, P))
    k_stego = hashlib.sha256(k_stego_input).digest()
    return k_stego

# Function to read messages from text files
def read_message(filename):
    """Reads a message from a text file."""
    with open(filename, "r") as f:
        return f.read()

# Masking function
def mask_secret(secret_message, m_1, k_stego):
    """Masks the secret message with the cover message m_1 and k_stego."""
    # Convert messages to binary strings
    secret_bin = ''.join(format(ord(c), '08b') for c in secret_message)
    m_1_bin = ''.join(format(ord(c), '08b') for c in m_1)
    k_stego_bin = ''.join(format(b, '08b') for b in k_stego)
    
    # Ensure all binaries are of the same length
    max_len = max(len(secret_bin), len(m_1_bin), len(k_stego_bin))
    secret_bin = secret_bin.ljust(max_len, '0')
    m_1_bin = m_1_bin.ljust(max_len, '0')
    k_stego_bin = k_stego_bin.ljust(max_len, '0')
    
    # XOR all the binaries
    masked_message = ''.join(
        str(int(secret_bin[i]) ^ int(m_1_bin[i]) ^ int(k_stego_bin[i]))
        for i in range(max_len)
    )
    return masked_message

# Example usage
if __name__ == "__main__":
    print(f"Loaded V_pri: {V_pri.hex()}")  # Tracing V_pri

    secret_message_file = "secret_message.txt"
    cover_message_file = "m1.txt"

    if not os.path.exists(secret_message_file) or not os.path.exists(cover_message_file):
        print("Secret message or cover message file not found.")
        exit(1)
    
    secret_message = read_message(secret_message_file)
    m_1 = read_message(cover_message_file)
    
    print(f"Secret Message: {secret_message}")
    print(f"Cover Message m_1: {m_1}")

    # Generate password P and stego-key k_stego
    P = generate_password(V_pri, m_1)
    print(f"Generated P (Password): {P.hex()}")  # Tracing P
    k_stego = generate_stego_key(V_pri, P)
    print(f"Generated k_stego: {k_stego.hex()}")  # Tracing k_stego

    # Mask the secret message
    masked_message = mask_secret(secret_message, m_1, k_stego)
    print(f"Masked Message (Binary): {masked_message[:64]}...")  # Display first 64 bits

    # Store the stego key and masked message
    with open("stego_key.txt", "wb") as f:
        f.write(k_stego)
    print("Stego key saved in 'stego_key.txt'.")

    with open("Masked Message (Binary).txt", "w") as f:
        f.write(masked_message)
    print("Masked message stored in 'Masked Message (Binary).txt'.")

