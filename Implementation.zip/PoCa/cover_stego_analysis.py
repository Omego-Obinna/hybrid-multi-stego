import numpy as np 
import matplotlib.pyplot as plt
from skimage import io, img_as_float
from skimage.metrics import peak_signal_noise_ratio, structural_similarity, mean_squared_error

# Load the images as float for accurate metric calculations
cover_image = img_as_float(io.imread("cover_image.png"))
stego_image = img_as_float(io.imread("stego_image.png"))

# Calculate PSNR
psnr_value = peak_signal_noise_ratio(cover_image, stego_image, data_range=1.0)
print(f"PSNR: {psnr_value:.2f} dB")

# Calculate MSE
mse_value = mean_squared_error(cover_image, stego_image)
print(f"MSE: {mse_value:.4f}")

# Calculate SSIM
ssim_value, ssim_map = structural_similarity(
    cover_image, stego_image, full=True, win_size=3, channel_axis=-1, data_range=1.0
)
print(f"SSIM: {ssim_value:.4f}")

# Function to customize font size and boldness
def set_font_options(ax, title_size=14, label_size=12, tick_size=10, bold=False):
    weight = 'bold' if bold else 'normal'
    ax.set_title(ax.get_title(), fontsize=title_size, weight=weight)
    ax.set_xlabel(ax.get_xlabel(), fontsize=label_size, weight=weight)
    ax.set_ylabel(ax.get_ylabel(), fontsize=label_size, weight=weight)
    ax.tick_params(axis='both', which='major', labelsize=tick_size)

# Plot SSIM Scatter Plot
plt.figure(figsize=(10, 8))
ssim_flat = ssim_map.flatten()
plt.scatter(range(len(ssim_flat)), ssim_flat, alpha=0.5, c=ssim_flat, cmap='viridis', edgecolor='none')
plt.colorbar(label="SSIM Value")
plt.title("SSIM Values Scatter Plot")
plt.xlabel("Pixel Index")
plt.ylabel("SSIM Value")
set_font_options(plt.gca(), title_size=16, label_size=14, tick_size=12, bold=True)
plt.show()

# Plot Image Quality Metrics Comparison as a Separate Plot
plt.figure(figsize=(10, 8))
metrics = ['PSNR', 'MSE', 'SSIM']
values = [psnr_value, mse_value, ssim_value]
bars = plt.bar(metrics, values, color=['blue', 'orange', 'green'])
plt.title("Image Quality Metrics Comparison")
plt.xlabel("Metrics")
plt.ylabel("Values")
set_font_options(plt.gca(), title_size=16, label_size=14, tick_size=12, bold=True)

# Add value labels on top of the bars
for bar, value in zip(bars, values):
    yval = bar.get_height()
    plt.text(bar.get_x() + bar.get_width() / 2, yval + 0.01, f"{value:.2f}", ha='center', va='bottom', fontweight='bold')
plt.show()

# Plot Cover and Stego Image Side-by-Side
plt.figure(figsize=(15, 5))
plt.imshow(np.concatenate((cover_image, stego_image), axis=1))
plt.title("Cover Image (Left) | Stego Image (Right)")
plt.axis("off")
plt.show()

