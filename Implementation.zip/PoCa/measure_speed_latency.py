import requests
import time
import pandas as pd
import os

# Constants for server URLs
server_1_url = "http://192.168.56.103:5001/send_m1"
server_2_url = "http://192.168.56.103:5002/send_m2"
server_3_url = "http://192.168.56.103:5003/receive_stego"

# Variables for data collection
data = {
    "Phase": [],
    "Data Size (KB)": [],
    "Transmission Time (s)": [],
    "Processing Latency (s)": []
}

# Function to calculate payload size in KB
def get_payload_size_kb(payload):
    if isinstance(payload, dict) and 'file' in payload:
        # If the payload includes a file, calculate its size separately
        file_size = os.path.getsize(payload['file'].name)
        # Return file size + estimated MAC size
        return (file_size + len(payload['mac'])) / 1024
    else:
        # For JSON data payloads, convert to string and calculate size
        return len(payload.encode('utf-8')) / 1024

# Function to measure transmission and processing latency
def measure_phase(phase_name, server_url, data_payload, iterations=100):
    for i in range(iterations):
        data_size_kb = get_payload_size_kb(data_payload)

        # Measure transmission time
        start_transmission = time.time()
        
        if phase_name == "Transmission Stego":
            response = requests.post(server_url, files={'file': data_payload['file']}, data={'mac': data_payload['mac']})
        else:
            response = requests.post(server_url, json=data_payload)
        
        end_transmission = time.time()
        transmission_time = end_transmission - start_transmission

        # Measure processing latency based on server response time
        processing_latency = response.elapsed.total_seconds()

        # Store metrics
        data["Phase"].append(phase_name)
        data["Data Size (KB)"].append(data_size_kb)
        data["Transmission Time (s)"].append(transmission_time)
        data["Processing Latency (s)"].append(processing_latency)
        
        print(f"{phase_name} - Iteration {i+1}: Data Size = {data_size_kb:.2f} KB, "
              f"Transmission Time = {transmission_time:.4f} s, "
              f"Processing Latency = {processing_latency:.4f} s")

# Example data payloads for each phase
m1_payload = '{"m_1": "A wind blows under a warm wind."}'
m2_payload = '{"m_2": "A mountain rises over a green mountain."}'
stego_payload = {'file': open('stego_image.png', 'rb'), 'mac': 'generated_mac_here'}

# Measure each phase
measure_phase("Transmission m_1", server_1_url, m1_payload)
measure_phase("Transmission m_2", server_2_url, m2_payload)
measure_phase("Transmission Stego", server_3_url, stego_payload)

# Save metrics to CSV
df = pd.DataFrame(data)
df.to_csv("protocol_detailed_metrics.csv", index=False)
print("Metrics saved to protocol_detailed_metrics.csv")

# Ensure to close the file after measuring
stego_payload['file'].close()

