import hmac
import hashlib
import secrets
import random

# Extended vocabulary for template-based cover generation
nouns = ["dog", "grass", "wind", "sun", "sky", "river", "sea", "mountain", "forest", "cloud"]
verbs = ["jumps", "flows", "blows", "shines", "runs", "sleeps", "rises", "sets", "whispers", "rustles"]
adjectives = ["quick", "bright", "lazy", "calm", "clear", "green", "blue", "cold", "warm", "soft"]
prepositions = ["over", "near", "above", "below", "beside", "beyond", "under", "within", "across", "through"]

# Templates for constructing sentences
templates = [
    "The {adj} {noun} {verb} {prep} the {noun}.",
    "A {noun} {verb} {prep} a {adj} {noun}.",
    "In the {adj} {noun}, the {noun} {verb} {prep} the {adj} {noun}.",
    "Every {noun} {verb} {prep} the {adj} {noun}.",
    "The {noun} {verb} {prep} the {adj} {noun} on a {adj} day."
]

# Setup phase to generate V_pri
def setup(secret_key, lambda_param):
    h = hmac.new(secret_key.encode(), str(lambda_param).encode(), hashlib.sha256)
    V_pri = h.digest()
    return V_pri

# Generate cover messages using the expanded template-based method
def generate_cover_message():
    template = random.choice(templates)
    cover_message = template.format(
        adj=random.choice(adjectives),
        noun=random.choice(nouns),
        verb=random.choice(verbs),
        prep=random.choice(prepositions)
    )
    return cover_message

# Synth phase to generate two cover messages
def synth(V_pri):
    random.seed(int.from_bytes(V_pri, byteorder='big'))  # Seed PRNG
    m_1 = generate_cover_message()
    m_2 = generate_cover_message()
    return m_1, m_2

# Example usage
if __name__ == "__main__":
    secret_key = "super_secret_key"
    lambda_param = 42
    V_pri = setup(secret_key, lambda_param)
    print(f"V_pri: {V_pri.hex()}")

    m_1, m_2 = synth(V_pri)
    print(f"Cover Message m_1: {m_1}")
    print(f"Cover Message m_2: {m_2}")

    # Save cover messages for further use
    with open("m1.txt", "w") as f:
        f.write(m_1)
    with open("m2.txt", "w") as f:
        f.write(m_2)

