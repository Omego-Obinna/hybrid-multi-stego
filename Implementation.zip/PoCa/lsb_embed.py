import hmac
import hashlib
import requests
import os
from PIL import Image
import numpy as np

# Function to embed a message into an image using LSB
def embed_lsb(image_path, masked_message, k_stego, output_path):
    """Embeds a masked message into an image using LSB."""
    img = Image.open(image_path)
    if img.mode == 'RGB' or img.mode == 'RGBA':
        img = img.convert('RGB')  
    else:
        img = img.convert('L')  

    pixels = np.array(img)
    flat_pixels = pixels.flatten()
    message_bits = list(masked_message)

    if len(message_bits) > len(flat_pixels):
        raise ValueError("Message is too large to embed in the image.")

    seed_value = int(hashlib.sha256(k_stego).hexdigest(), 16) % (2**32)
    np.random.seed(seed_value)
    indices = np.arange(len(flat_pixels))
    np.random.shuffle(indices)

    for i, bit in enumerate(message_bits):
        flat_pixels[indices[i]] = (flat_pixels[indices[i]] & ~1) | int(bit)

    stego_pixels = flat_pixels.reshape(pixels.shape)
    stego_image = Image.fromarray(stego_pixels.astype(np.uint8))

    if output_path.lower().endswith('.jpg') or output_path.lower().endswith('.jpeg'):
        stego_image.save(output_path, 'JPEG', quality=95)
    else:
        stego_image.save(output_path, 'PNG')

    print(f"Stego-image saved as {output_path}")

    return output_path

# Function to generate HMAC for message integrity
def generate_mac(stego_image_path, V_pri):
    with open(stego_image_path, "rb") as image_file:
        stego_image_data = image_file.read()
        
    print(f"First 64 bytes of stego image (Amara): {stego_image_data[:64]}")
    mac = hmac.new(V_pri, stego_image_data, hashlib.sha256).hexdigest()
    return mac

# Function to send the stego-image and MAC via HTTP (third channel)
def send_stego_and_mac(stego_image_path, mac, server_url):
    with open(stego_image_path, "rb") as image_file:
        files = {'file': image_file}
        data = {'mac': mac}
        response = requests.post(server_url, files=files, data=data)
    return response.json()

# Function to read the masked message from a text file
def read_masked_message(filename):
    with open(filename, "r") as file:
        return file.read()

# Function to read the stego key from a binary file
def read_stego_key(filename):
    """Reads the stego key from a binary file."""
    with open(filename, "rb") as file:
        return file.read()

# Example usage
if __name__ == "__main__":
    image_path = "cover_image.png"  
    output_path = "stego_image.png"  
    masked_message_file = "Masked Message (Binary).txt"
    stego_key_file = "stego_key.txt"  
    if not os.path.exists(masked_message_file):
        print(f"Masked message file '{masked_message_file}' not found.")
        exit(1)

    masked_message = read_masked_message(masked_message_file)
    print(f"Masked Message: {masked_message[:64]}...")  

    k_stego = read_stego_key(stego_key_file)
    print(f"Loaded k_stego: {k_stego.hex()}")

    V_pri = bytes.fromhex('b76852100c93c73966cb1b909abff1a08124b3f4f9357495fefdabe13998fac6')  

    stego_image_path = embed_lsb(image_path, masked_message, k_stego, output_path)

    mac = generate_mac(stego_image_path, V_pri)
    print(f"Generated MAC: {mac}")

    server_url = "http://192.168.56.103:5003/receive_stego"  
    response = send_stego_and_mac(stego_image_path, mac, server_url)
    print(f"Server Response: {response}")

