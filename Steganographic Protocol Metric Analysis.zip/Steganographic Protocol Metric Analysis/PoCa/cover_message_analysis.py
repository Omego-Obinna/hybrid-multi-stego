import os
import math
import numpy as np
import textstat
import nltk
from collections import Counter
import matplotlib.pyplot as plt
import matplotlib as mpl
import matplotlib.font_manager as fm

# --- NLTK Download (for first-time runs) ---
nltk.download('punkt')
nltk.download('words')

# --- Customization Options & Global Styles ---
# Font setup: bundle .ttf fonts in ./fonts directory
FONT_DIR = os.path.join(os.path.dirname(__file__), 'fonts')
if os.path.isdir(FONT_DIR):
    for fname in os.listdir(FONT_DIR):
        if fname.lower().endswith('.ttf'):
            fm.fontManager.addfont(os.path.join(FONT_DIR, fname))

# Matplotlib global rc settings
mpl.rcParams.update({
    # Font families
    'font.family': 'sans-serif',
    'font.sans-serif': ['Arial', 'DejaVu Sans'],
    # Title and label styles
    'axes.titlesize': 14,
    'axes.titleweight': 'bold',
    'axes.titlepad': 10,
    'axes.labelsize': 12,
    'axes.labelweight': 'bold',
    'axes.labelpad': 8,
    # Tick labels
    'xtick.labelsize': 10,
    'ytick.labelsize': 10,
    'xtick.major.size': 5,
    'ytick.major.size': 5,
    'xtick.major.width': 1,
    'ytick.major.width': 1,
    # Legend
    'legend.fontsize': 10,
    'legend.title_fontsize': 10,
    'legend.frameon': True,
    'legend.edgecolor': 'gray',
    # Axes frame
    'axes.edgecolor': 'lightgray',
    'axes.linewidth': 4.5,
    # Grid styling
    'grid.color': 'lightgray',
    'grid.linestyle': '-',
    'grid.linewidth': 1.0,
    'axes.grid': True,
    'axes.grid.axis': 'y',
    # Figure settings
    'figure.figsize': (8, 6),
    'figure.dpi': 100,
    # Line & marker defaults
    'lines.linewidth': 2,
    'lines.markersize': 6,
    # Savefig defaults
    'savefig.dpi': 250,
    'savefig.bbox': 'tight'
})

# Plot customization variables
ENTROPY_CMAP = 'Blues'            # sequential colormap for entropies
READABILITY_CMAP = 'winter'        # sequential colormap for readability
GRAMMAR_COLOR = 'darkorange'        # color for grammar level line
BAR_WIDTH = 0.8                    # width of bars
VALUE_LABEL_KWARGS = {             # styling for value labels on bars
    'fontsize': 8,
    'weight': 'normal',
    'padding': 2
}
cover_messages = [
    "laughs as they run through the tall grass.",
    "hops quietly through the garden, nibbling on fresh clover.",
    "scattering them across the ground.",
    "soft glow on the peaceful village below.",
    "flows steadily, reflecting the golden light of dusk.",
    "scent of pine trees through the forest",
    "against the shore, creating a soothing rhythm.",
    "stars twinkle brightly in the clear night sky",
    "the park as the trees sway in the breeze.",
    "softly in the tranquil night sky",
    "cottage spills onto the cobbled street below",
    "cloud floats across the sky, casting a soft shadow over the land.",
    "the shore, creating a soothing rhythm.",
    "gentle breeze sweeps across the field of wildflowers.",
    "The path winds through the woods, leading toward a quiet clearing."
    "sun rises in the early morning sky."
    "the trees sway in the breeze.",
    "through the autumn leaves, scattering them across the ground.",
    "Philosophers and policymakers continue to debate the implications of AI on employment, human rights, and social structures.",
    "binary logic (0s and 1s), quantum computers leverage the principles of superposition and entanglement to perform complex calculations at speeds.",
    "they run through the tall grass.",
    "deep neural networks, and natural language processing systems have demonstrated remarkable capabilities in areas such as language translation, medical diagnosis,.",
    "imperative to balance progress with ethical considerations, ensuring that the tools we create serve as catalysts for positive societal change.",
    "A gentle breeze blows over the green field.",
    "and technological advancement offers a roadmap toward a future where knowledge is leveraged for the betterment of society.",
    "techniques, such as RSA encryption and quantum key distribution, leverage mathematical constructs to enhance data security. Quantum computing represents another.",
    "An ideal approach is to formalize knowledge through mathematical models and empirical validation became the cornerstone of scientific progress.",
    "civilizations progressed, the need for more sophisticated methods of information storage became apparent.",
    "networks have the ability to generate coherent and meaningful narratives has been a hallmark of human creativity.",
    "principles of steganography, which involve embedding hidden messages within innocuous content, have been used for centuries to conceal information"
]

# Entropy Calculation for Cover Messages
# --- Analysis Functions ---
def calculate_entropy(text):
    """Compute Shannon entropy of a string."""
    counts = Counter(text)
    total = sum(counts.values())
    probs = np.array(list(counts.values())) / total
    return -np.sum(probs * np.log2(probs))


def check_linguistic_plausibility(text):
    """Assess readability and grade level."""
    readability = textstat.flesch_reading_ease(text)
    grade_level = textstat.text_standard(text, float_output=True)
    return readability, grade_level


def set_font_options(ax, title_size=14, label_size=12, tick_size=10, bold=False):
    """Adjust font sizes and weights for a given axis."""
    weight = 'bold' if bold else 'normal'
    ax.set_title(ax.get_title(), fontsize=title_size, weight=weight)
    ax.set_xlabel(ax.get_xlabel(), fontsize=label_size, weight=weight)
    ax.set_ylabel(ax.get_ylabel(), fontsize=label_size, weight=weight)
    ax.tick_params(axis='both', which='major', labelsize=tick_size)


# --- Main Analysis & Plotting ---
def analyze_and_plot(messages,
                     title_size=14,
                     label_size=12,
                     tick_size=10,
                     bold=True):
    message_ids = np.arange(1, len(messages) + 1)
    entropies = []
    readability_scores = []
    grammar_levels = []

    print("Cover Message Analysis Report:\n")
    for idx, msg in enumerate(messages, start=1):
        ent = calculate_entropy(msg)
        entropies.append(ent)
        print(f"Message {idx}: Entropy = {ent:.4f}")
    print("\nLinguistic Plausibility Check:")
    for idx, msg in enumerate(messages, start=1):
        read, grade = check_linguistic_plausibility(msg)
        readability_scores.append(read)
        grammar_levels.append(grade)
        print(f"Message {idx}: Readability = {read:.2f}, Grade Level = {grade}")

    # --- Entropy Bar Chart ---
    fig, ax1 = plt.subplots()
    cmap1 = plt.get_cmap(ENTROPY_CMAP)
    colors1 = cmap1(np.linspace(0.4, 0.8, len(entropies)))
    bars1 = ax1.bar(message_ids, entropies,
                    width=BAR_WIDTH,
                    color=colors1,
                    edgecolor='black')
    ax1.set_title('Entropy Calculation for Cover Messages')
    ax1.set_xlabel('Message ID')
    ax1.set_ylabel('Entropy Value')
    set_font_options(ax1, title_size, label_size, tick_size, bold)
    ax1.grid(axis='y')
    ax1.bar_label(bars1, fmt='%.2f', **VALUE_LABEL_KWARGS)
    plt.tight_layout()
    plt.show()

    # --- Readability & Grammar Plot ---
    fig, ax2 = plt.subplots()
    cmap2 = plt.get_cmap(READABILITY_CMAP)
    colors2 = cmap2(np.linspace(0.4, 0.8, len(readability_scores)))
    bars2 = ax2.bar(message_ids, readability_scores,
                    width=BAR_WIDTH,
                    color=colors2,
                    edgecolor='black',
                    label='Readability Index')
    ax2.set_xlabel('Message ID')
    ax2.set_ylabel('Readability Index')
    set_font_options(ax2, title_size, label_size, tick_size, bold)
    ax2.grid(axis='y')
    ax2.bar_label(bars2, fmt='%.1f', **VALUE_LABEL_KWARGS)

    ax3 = ax2.twinx()
    line3, = ax3.plot(message_ids, grammar_levels,
                      color=GRAMMAR_COLOR,
                      marker='o',
                      linewidth=2,
                      label='Grammar Level')
    ax3.set_ylabel('Grammar Level')
    ax3.tick_params(axis='y', labelcolor=GRAMMAR_COLOR)
    ax3.grid(False)

    ax2.set_title('Linguistic Plausibility for Cover Messages')
    # Combine legends
    bars2_label = bars2
    handles = [bars2, line3]
    labels = ['Readability Index', 'Grammar Level']
    ax2.legend(handles, labels, loc='upper right')

    plt.tight_layout()
    plt.show()


# --- Script Entry Point ---
if __name__ == '__main__':
    analyze_and_plot(cover_messages)

