import pandas as pd
import matplotlib.pyplot as plt

# Load data from CSV file
df = pd.read_csv("protocol_detailed_metrics.csv")

# Summary Table for each phase
summary_table = df.groupby("Phase").agg({
    "Data Size (KB)": ['mean', 'std'],
    "Transmission Time (s)": ['mean', 'std'],
    "Processing Latency (s)": ['mean', 'std']
})
print("Summary Table:\n", summary_table)

# Function to customize font size and boldness
def set_font_options(ax, title_size=14, label_size=12, tick_size=10, bold=False):
    weight = 'bold' if bold else 'normal'
    ax.set_title(ax.get_title(), fontsize=title_size, weight=weight)
    ax.set_xlabel(ax.get_xlabel(), fontsize=label_size, weight=weight)
    ax.set_ylabel(ax.get_ylabel(), fontsize=label_size, weight=weight)
    ax.tick_params(axis='both', which='major', labelsize=tick_size)

# Ensure consistent phase ordering
phases = sorted(df['Phase'].unique())

# Define colors for each phase
colors = ['blue', 'orange', 'green']  # Adjust if you have more phases

# Variable-width Box Plot for Transmission Time over Multiple Runs
data_transmission = [df[df['Phase'] == phase]['Transmission Time (s)'] for phase in phases]
counts_transmission = [len(d) for d in data_transmission]
total_count_transmission = sum(counts_transmission)
widths_transmission = [count / total_count_transmission for count in counts_transmission]
# Scale widths for better visibility
widths_transmission = [w * 0.9 / max(widths_transmission) for w in widths_transmission]

positions = range(1, len(phases) + 1)

plt.figure(figsize=(10, 8))
bp = plt.boxplot(data_transmission, widths=widths_transmission, positions=positions, patch_artist=True)

# Set colors for each box
for patch, color in zip(bp['boxes'], colors):
    patch.set_facecolor(color)

# Set x-axis labels
plt.xticks(positions, phases)

# Set titles and labels
plt.title("Transmission Time over Multiple Runs")
plt.xlabel("Phase")
plt.ylabel("Transmission Time (s)")
plt.grid(True, axis='y', linestyle='--', alpha=0.7)

ax = plt.gca()
set_font_options(ax, title_size=16, label_size=14, tick_size=12, bold=True)
plt.show()

# Variable-width Box Plot for Processing Latency over Multiple Runs
data_processing = [df[df['Phase'] == phase]['Processing Latency (s)'] for phase in phases]
counts_processing = [len(d) for d in data_processing]
total_count_processing = sum(counts_processing)
widths_processing = [count / total_count_processing for count in counts_processing]
# Scale widths for better visibility
widths_processing = [w * 0.9 / max(widths_processing) for w in widths_processing]

plt.figure(figsize=(10, 8))
bp = plt.boxplot(data_processing, widths=widths_processing, positions=positions, patch_artist=True)

# Set colors for each box
for patch, color in zip(bp['boxes'], colors):
    patch.set_facecolor(color)

# Set x-axis labels
plt.xticks(positions, phases)

# Set titles and labels
plt.title("Processing Latency over Multiple Runs")
plt.xlabel("Phase")
plt.ylabel("Processing Latency (s)")
plt.grid(True, axis='y', linestyle='--', alpha=0.7)

ax = plt.gca()
set_font_options(ax, title_size=16, label_size=14, tick_size=12, bold=True)
plt.show()

