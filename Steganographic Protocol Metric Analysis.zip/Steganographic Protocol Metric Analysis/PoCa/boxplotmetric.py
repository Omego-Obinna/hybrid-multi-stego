import pandas as pd
import matplotlib.pyplot as plt

# Data for Protocol Phase Durations
data = {
    "Phase": [
        "Setup and Synth", 
        "Send Cover Messages", 
        "Mask Secret", 
        "Embed Secret", 
        "Transmit Stego", 
        "Decode Message"
    ],
    "Duration (s)": [
        0.009173155, 
        0.084788561, 
        0.101090908, 
        0.200459719, 
        0.300440311, 
        0.100396633
    ]
}

# Create DataFrame
df = pd.DataFrame(data)

# Create a bar chart for each protocol phase with durations
plt.figure(figsize=(10, 6))
plt.bar(df["Phase"], df["Duration (s)"], color='skyblue')
plt.ylabel('Duration (seconds)')
plt.title('Protocol Phase Durations')
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.show()

