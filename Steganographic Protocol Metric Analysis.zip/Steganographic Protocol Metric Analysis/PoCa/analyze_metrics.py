import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
import matplotlib.font_manager as fm

# --- Font setup ---
font_dir = os.path.join(os.path.dirname(__file__), 'fonts')
if os.path.isdir(font_dir):
    for fname in os.listdir(font_dir):
        if fname.lower().endswith('.ttf'):
            fm.fontManager.addfont(os.path.join(font_dir, fname))

# --- Global style settings ---
mpl.rcParams.update({
    # Font settings
    'font.family': 'sans-serif',
    'font.sans-serif': ['Arial', 'DejaVu Sans'],
    # Title and label styles
    'axes.titlesize': 14,
    'axes.titleweight': 'bold',
    'axes.titlepad': 12,
    'axes.labelsize': 12,
    'axes.labelweight': 'bold',
    # Tick labels
    'xtick.labelsize': 10,
    'ytick.labelsize': 10,
    # Line settings
    'lines.linewidth': 2,
    # Axis frame styling (light gray)
    'axes.edgecolor': 'lightgray',
    'axes.linewidth': 4.5,
    # Grid styling (both horizontal and vertical)
    'axes.grid': True,
    'axes.grid.axis': 'both',
    'grid.color': 'lightgray',
    'grid.linestyle': '-',
    'grid.linewidth': 1,
    # Boxplot defaults
    'boxplot.boxprops.linewidth': 2.0,
    'boxplot.boxprops.color': 'black',
    'boxplot.whiskerprops.linewidth': 2.0,
    'boxplot.whiskerprops.color': 'gray',
    'boxplot.capprops.linewidth': 2,
    'boxplot.capprops.color': 'gray',
    'boxplot.medianprops.linewidth': 2,
    'boxplot.medianprops.color': 'firebrick',
    'boxplot.flierprops.markersize': 6,
    'boxplot.flierprops.markerfacecolor': 'white',
    'boxplot.flierprops.markeredgecolor': 'lightgray',
    # Figure size
    'figure.figsize': (8, 6),
})

# --- Boxplot colormap setting ---
# You can choose any qualitative cmap, e.g., 'Set1', 'Set2', 'Set3', 'Pastel1', 'Pastel2',
# 'Paired', 'Accent', 'Dark2', 'tab10', 'tab20'
boxplot_cmap = 'tab20'
# Spacing multiplier between boxes (1.0 = default, >1 spreads them out)
box_spacing = 1.08

# --- Load data ---
current_dir = os.path.dirname(__file__)
df = pd.read_csv(os.path.join(current_dir, "protocol_detailed_metrics.csv"))

# --- Summary table ---
summary = df.groupby("Phase").agg({
    "Data Size (KB)": ['mean', 'std'],
    "Transmission Time (s)": ['mean', 'std'],
    "Processing Latency (s)": ['mean', 'std']
}).round(3)
print("Summary Table (Mean ± Std):")
summary.columns = ['_'.join(col) for col in summary.columns]
print(summary)

# --- Label mapping ---
phases = sorted(df['Phase'].unique())
label_map = {
    'Transmission Stego': 'Stego-object',
    'Transmission m_1': 'cover-message 1',
    'Transmission m_2': 'cover-message 2'
}
display_labels = [label_map.get(phase, phase) for phase in phases]

# --- Palette & data columns ---
palette = plt.get_cmap(boxplot_cmap).colors[:len(phases)]
data_cols = [
    ("Transmission Time (s)", "Transmission Time by Phase"),
    ("Processing Latency (s)", "Processing Latency by Phase")
]

# --- Plot function ---
def plot_phase_boxplot(col, title):
    data = [df[df['Phase']==phase][col] for phase in phases]
    counts = [len(d) for d in data]
    max_n = max(counts)
    widths = [0.3 + 0.7*(n/max_n) for n in counts]

    positions = np.arange(len(phases)) * box_spacing
    fig, ax = plt.subplots()
    bp = ax.boxplot(
        data,
        positions=positions,
        widths=widths,
        notch=True,
        patch_artist=True
    )
    for patch, color in zip(bp['boxes'], palette):
        patch.set_facecolor(color)
    for i, series in enumerate(data):
        y = series.values
        x = np.random.normal(positions[i], 0.04, size=len(y))
        ax.scatter(x, y, s=12, alpha=0.25, color='black')
    for i, n in enumerate(counts):
        ax.text(positions[i], max(data[i])*1.03, f'n={n}', ha='center', fontsize=10)
    ax.set_xticks(positions)
    ax.set_xticklabels(display_labels)
    ax.set_xlim(positions[0] - box_spacing*0.5, positions[-1] + box_spacing*0.5)
    ax.set_ylabel(col)
    ax.set_title(title)
    ax.grid(True)
    plt.tight_layout()
    plt.show()

# --- Generate plots ---
for col_name, plot_title in data_cols:
    plot_phase_boxplot(col_name, plot_title)

